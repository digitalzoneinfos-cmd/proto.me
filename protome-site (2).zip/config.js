/* PROTO.ME — configuration publique
   Collez ici l'URL et la clé « anon public » de votre projet Supabase
   (Supabase > Project Settings > API). Ces deux valeurs sont faites pour être publiques :
   la sécurité est assurée par les règles de la base (RLS), pas par ce fichier.
   Ne mettez JAMAIS ici la clé « service_role » ni un mot de passe. */
window.PROTOME_CONFIG = {
  supabaseUrl: '',      // ex. 'https://abcdefgh.supabase.co'
  supabaseAnonKey: '',  // ex. 'eyJhbGciOi...'
  whatsapp: '213555635842'
};
